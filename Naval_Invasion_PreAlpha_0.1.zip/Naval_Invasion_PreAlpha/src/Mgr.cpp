/*
 * Mgr.cpp
 *
 *  Created on: Mar 4, 2018
 *      Author: sushil
 */

#include <Engine.h>
#include <Mgr.h>

Mgr::Mgr(Engine *engine) {
	// TODO Auto-generated constructor stub
	this->engine = engine;

}

Mgr::~Mgr() {
	// TODO Auto-generated destructor stub
}

void Mgr::Init(){

}

void Mgr::LoadLevel(){

}

void Mgr::Stop(){

}

void Mgr::Tick(float dt){

}
