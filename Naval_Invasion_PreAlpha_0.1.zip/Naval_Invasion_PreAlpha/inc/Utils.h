/*
 * Utils.h
 *
 *  Created on: Mar 1, 2018
 *      Author: sushil
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <string>

float FixAngle(float angle);
float Clamp(float min, float max, float val);
std::string IntToString(int x);


#endif /* UTILS_H_ */
